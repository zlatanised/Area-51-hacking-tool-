# Area51

1.Exposing how choice master can be used to exploit a person's personal data and his/her images without consent.

2.Exposing how choice master can be used to hijack social media account credentials without the knowledge of the victim and then                            use it for unethical practices. 

3.Our main goal is to demonstrate how a hacker does the above with the help of choice-master and then give the solution for it.

